<?php
include('views/templates/header.php');

include('views/templates/footer.php');