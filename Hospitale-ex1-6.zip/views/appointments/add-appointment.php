<form method="POST" action="">

  <!-- Email input -->
  <div class="form-outline mb-4">
    <input type="datetime-local" value="<?=$dateHour ?? ''?>" required id="dateHour" class="form-control" placeholder="YYYY-dd-mm hh:mm" name="dateHour" pattern="(\d{4}-\d{2}-\d{1,2}(T| )\d{2}:\d{2})" />
    <label class="form-label" for="dateHour"></label>
  </div>
  <div class="invalid-feedback-2"><?= $errorsArray['dateHour_error'] ?? ''?></div>

  <!-- Password input -->
  <div class="form-outline mb-4">
    <select name="idPatients" id="idPatients" class="form-control" required>
        <option value="">--Please choose a Patient--</option>


        <?php
        // $allPatients est un tableau (à créer) qui contient tous les patients
        foreach($allPatients as $patient){
        ?>
            <option value="<?=$patient->id?>" <?= ($patient->id==$idPatients) ? 'selected' : ''?>><?=$patient->lastname?> <?=$patient->firstname?></option>

        <?php } ?>



    </select>
    <label class="form-label" for="idPatients"></label>
    
  </div>
  <div class="invalid-feedback-2"><?= $errorsArray['idPatients_error'] ?? ''?></div>

  <!-- Submit button -->
  <button type="submit" class="btn btn-primary btn-block">Enregistrer le rendez-vous</button>
</form>