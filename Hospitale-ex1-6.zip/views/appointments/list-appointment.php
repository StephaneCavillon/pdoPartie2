<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Date et heure</th>
      <th scope="col">Nom</th>
      <th scope="col">Prénom</th>
    </tr>
  </thead>
  <tbody>

    <?php 
    foreach($appointments as $appointment) {
        ?>
        <tr>
            <th scope="row"><?=htmlentities($appointment->idAppointment)?></th>
            <td><?=htmlentities($appointment->dateHour)?></td>
            <td><?=htmlentities($appointment->lastname)?></td>
            <td><?=htmlentities($appointment->firstname)?></td>
        </tr>
    <?php } ?>

  </tbody>
</table>